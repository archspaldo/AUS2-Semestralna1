#pragma once
#include <QtWidgets/qwidget.h>
#include "ui_QT_location_information.h"
#include "Controller.h"

class QLocationInformation
{

};

