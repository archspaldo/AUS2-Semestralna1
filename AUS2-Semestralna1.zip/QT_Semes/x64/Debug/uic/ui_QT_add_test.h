/********************************************************************************
** Form generated from reading UI file 'QT_add_test.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_ADD_TEST_H
#define UI_QT_ADD_TEST_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_Dialog_add_test
{
public:
    QGridLayout *gridLayout;
    QLabel *label_8;
    QLabel *label_5;
    QHBoxLayout *hboxLayout;
    QSpacerItem *spacerItem;
    QPushButton *okButton;
    QPushButton *cancelButton;
    QLineEdit *lineEdit_8;
    QLabel *label_7;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_3;
    QSpacerItem *verticalSpacer;
    QLabel *label_6;
    QLabel *label_4;
    QCheckBox *checkBox;
    QDateTimeEdit *dateTimeEdit;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QSpinBox *spinBox_3;

    void setupUi(QDialog *Dialog_add_test)
    {
        if (Dialog_add_test->objectName().isEmpty())
            Dialog_add_test->setObjectName(QString::fromUtf8("Dialog_add_test"));
        Dialog_add_test->resize(400, 300);
        gridLayout = new QGridLayout(Dialog_add_test);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_8 = new QLabel(Dialog_add_test);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 6, 0, 1, 1);

        label_5 = new QLabel(Dialog_add_test);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 3, 0, 1, 1);

        hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout->setSpacing(6);
#endif
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        spacerItem = new QSpacerItem(131, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        okButton = new QPushButton(Dialog_add_test);
        okButton->setObjectName(QString::fromUtf8("okButton"));

        hboxLayout->addWidget(okButton);

        cancelButton = new QPushButton(Dialog_add_test);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        hboxLayout->addWidget(cancelButton);


        gridLayout->addLayout(hboxLayout, 8, 0, 1, 3);

        lineEdit_8 = new QLineEdit(Dialog_add_test);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setReadOnly(false);

        gridLayout->addWidget(lineEdit_8, 6, 2, 1, 1);

        label_7 = new QLabel(Dialog_add_test);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 5, 0, 1, 1);

        label = new QLabel(Dialog_add_test);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEdit = new QLineEdit(Dialog_add_test);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setReadOnly(false);

        gridLayout->addWidget(lineEdit, 0, 2, 1, 1);

        label_3 = new QLabel(Dialog_add_test);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 1, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 7, 0, 1, 3);

        label_6 = new QLabel(Dialog_add_test);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 4, 0, 1, 1);

        label_4 = new QLabel(Dialog_add_test);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        checkBox = new QCheckBox(Dialog_add_test);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout->addWidget(checkBox, 1, 2, 1, 1);

        dateTimeEdit = new QDateTimeEdit(Dialog_add_test);
        dateTimeEdit->setObjectName(QString::fromUtf8("dateTimeEdit"));
        dateTimeEdit->setDateTime(QDateTime(QDate(2021, 11, 18), QTime(17, 0, 0)));
        dateTimeEdit->setDate(QDate(2021, 11, 18));
        dateTimeEdit->setCalendarPopup(true);

        gridLayout->addWidget(dateTimeEdit, 2, 2, 1, 1);

        spinBox = new QSpinBox(Dialog_add_test);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));

        gridLayout->addWidget(spinBox, 3, 2, 1, 1);

        spinBox_2 = new QSpinBox(Dialog_add_test);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));

        gridLayout->addWidget(spinBox_2, 4, 2, 1, 1);

        spinBox_3 = new QSpinBox(Dialog_add_test);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));

        gridLayout->addWidget(spinBox_3, 5, 2, 1, 1);

        QWidget::setTabOrder(lineEdit, checkBox);
        QWidget::setTabOrder(checkBox, dateTimeEdit);
        QWidget::setTabOrder(dateTimeEdit, spinBox);
        QWidget::setTabOrder(spinBox, spinBox_2);
        QWidget::setTabOrder(spinBox_2, spinBox_3);
        QWidget::setTabOrder(spinBox_3, lineEdit_8);
        QWidget::setTabOrder(lineEdit_8, okButton);
        QWidget::setTabOrder(okButton, cancelButton);

        retranslateUi(Dialog_add_test);
        QObject::connect(okButton, &QPushButton::clicked, Dialog_add_test, qOverload<>(&QDialog::accept));
        QObject::connect(cancelButton, &QPushButton::clicked, Dialog_add_test, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(Dialog_add_test);
    } // setupUi

    void retranslateUi(QDialog *Dialog_add_test)
    {
        Dialog_add_test->setWindowTitle(QCoreApplication::translate("Dialog_add_test", "Dialog", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog_add_test", "Koment\303\241r", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog_add_test", "Kraj", nullptr));
        okButton->setText(QCoreApplication::translate("Dialog_add_test", "OK", nullptr));
        cancelButton->setText(QCoreApplication::translate("Dialog_add_test", "Cancel", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog_add_test", "Testovacia stanica", nullptr));
        label->setText(QCoreApplication::translate("Dialog_add_test", "Rodn\303\251 \304\215\303\255slo", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog_add_test", "V\303\275sledok", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog_add_test", "Okres", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog_add_test", "D\303\241tum testovania", nullptr));
        checkBox->setText(QCoreApplication::translate("Dialog_add_test", "Pozit\303\255vny", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_add_test: public Ui_Dialog_add_test {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_ADD_TEST_H
