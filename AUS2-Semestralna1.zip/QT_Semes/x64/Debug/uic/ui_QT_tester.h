/********************************************************************************
** Form generated from reading UI file 'QT_tester.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_TESTER_H
#define UI_QT_TESTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog_tester
{
public:
    QGridLayout *gridLayout;
    QLabel *label_4;
    QSpinBox *spinBox_2;
    QLabel *label_3;
    QPushButton *pushButton;
    QLabel *label_5;
    QSpinBox *spinBox_5;
    QSpinBox *spinBox_3;
    QLabel *label_2;
    QLabel *label;
    QSpinBox *spinBox_4;
    QSpinBox *spinBox;
    QTableView *tableView;

    void setupUi(QWidget *Dialog_tester)
    {
        if (Dialog_tester->objectName().isEmpty())
            Dialog_tester->setObjectName(QString::fromUtf8("Dialog_tester"));
        Dialog_tester->resize(582, 430);
        gridLayout = new QGridLayout(Dialog_tester);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_4 = new QLabel(Dialog_tester);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 1, 2, 1, 1);

        spinBox_2 = new QSpinBox(Dialog_tester);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(spinBox_2->sizePolicy().hasHeightForWidth());
        spinBox_2->setSizePolicy(sizePolicy);
        spinBox_2->setMinimum(1);

        gridLayout->addWidget(spinBox_2, 1, 1, 1, 1);

        label_3 = new QLabel(Dialog_tester);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        pushButton = new QPushButton(Dialog_tester);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 3, 0, 1, 4);

        label_5 = new QLabel(Dialog_tester);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 2, 2, 1, 1);

        spinBox_5 = new QSpinBox(Dialog_tester);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        spinBox_5->setMinimum(1);

        gridLayout->addWidget(spinBox_5, 2, 3, 1, 1);

        spinBox_3 = new QSpinBox(Dialog_tester);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        sizePolicy.setHeightForWidth(spinBox_3->sizePolicy().hasHeightForWidth());
        spinBox_3->setSizePolicy(sizePolicy);
        spinBox_3->setMinimum(1);

        gridLayout->addWidget(spinBox_3, 1, 3, 1, 1);

        label_2 = new QLabel(Dialog_tester);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        label = new QLabel(Dialog_tester);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        spinBox_4 = new QSpinBox(Dialog_tester);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setMinimum(1);

        gridLayout->addWidget(spinBox_4, 2, 1, 1, 1);

        spinBox = new QSpinBox(Dialog_tester);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setMinimum(100);
        spinBox->setMaximum(10000);

        gridLayout->addWidget(spinBox, 0, 1, 1, 3);

        tableView = new QTableView(Dialog_tester);
        tableView->setObjectName(QString::fromUtf8("tableView"));

        gridLayout->addWidget(tableView, 4, 0, 1, 4);

        QWidget::setTabOrder(spinBox, spinBox_2);
        QWidget::setTabOrder(spinBox_2, spinBox_4);
        QWidget::setTabOrder(spinBox_4, spinBox_3);
        QWidget::setTabOrder(spinBox_3, spinBox_5);
        QWidget::setTabOrder(spinBox_5, pushButton);

        retranslateUi(Dialog_tester);

        QMetaObject::connectSlotsByName(Dialog_tester);
    } // setupUi

    void retranslateUi(QWidget *Dialog_tester)
    {
        Dialog_tester->setWindowTitle(QCoreApplication::translate("Dialog_tester", "Form", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog_tester", "Vyber prvok", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog_tester", "Vyma\305\276", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialog_tester", "Spusti\305\245", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog_tester", "Interval", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog_tester", "Vlo\305\276", nullptr));
        label->setText(QCoreApplication::translate("Dialog_tester", "Po\304\215et oper\303\241cii", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_tester: public Ui_Dialog_tester {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_TESTER_H
