/********************************************************************************
** Form generated from reading UI file 'QT_add_person.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_ADD_PERSON_H
#define UI_QT_ADD_PERSON_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_Dialog_add_person
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_2;
    QHBoxLayout *hboxLayout;
    QSpacerItem *spacerItem;
    QPushButton *okButton;
    QPushButton *cancelButton;
    QSpacerItem *verticalSpacer;
    QLabel *label;

    void setupUi(QDialog *Dialog_add_person)
    {
        if (Dialog_add_person->objectName().isEmpty())
            Dialog_add_person->setObjectName(QString::fromUtf8("Dialog_add_person"));
        Dialog_add_person->resize(372, 242);
        gridLayout = new QGridLayout(Dialog_add_person);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lineEdit_3 = new QLineEdit(Dialog_add_person);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setReadOnly(false);

        gridLayout->addWidget(lineEdit_3, 2, 1, 1, 1);

        label_3 = new QLabel(Dialog_add_person);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        lineEdit = new QLineEdit(Dialog_add_person);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setReadOnly(false);

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        lineEdit_2 = new QLineEdit(Dialog_add_person);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setReadOnly(false);

        gridLayout->addWidget(lineEdit_2, 1, 1, 1, 1);

        label_2 = new QLabel(Dialog_add_person);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout->setSpacing(6);
#endif
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        spacerItem = new QSpacerItem(131, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        okButton = new QPushButton(Dialog_add_person);
        okButton->setObjectName(QString::fromUtf8("okButton"));

        hboxLayout->addWidget(okButton);

        cancelButton = new QPushButton(Dialog_add_person);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        hboxLayout->addWidget(cancelButton);


        gridLayout->addLayout(hboxLayout, 4, 0, 1, 2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 3, 0, 1, 2);

        label = new QLabel(Dialog_add_person);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        QWidget::setTabOrder(lineEdit, lineEdit_2);
        QWidget::setTabOrder(lineEdit_2, lineEdit_3);
        QWidget::setTabOrder(lineEdit_3, okButton);
        QWidget::setTabOrder(okButton, cancelButton);

        retranslateUi(Dialog_add_person);
        QObject::connect(cancelButton, &QPushButton::clicked, Dialog_add_person, qOverload<>(&QDialog::reject));
        QObject::connect(okButton, &QPushButton::clicked, Dialog_add_person, qOverload<>(&QDialog::accept));

        QMetaObject::connectSlotsByName(Dialog_add_person);
    } // setupUi

    void retranslateUi(QDialog *Dialog_add_person)
    {
        Dialog_add_person->setWindowTitle(QCoreApplication::translate("Dialog_add_person", "Dialog", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog_add_person", "Priezvisko", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog_add_person", "Meno", nullptr));
        okButton->setText(QCoreApplication::translate("Dialog_add_person", "OK", nullptr));
        cancelButton->setText(QCoreApplication::translate("Dialog_add_person", "Cancel", nullptr));
        label->setText(QCoreApplication::translate("Dialog_add_person", "Rodn\303\251 \304\215\303\255slo", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_add_person: public Ui_Dialog_add_person {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_ADD_PERSON_H
