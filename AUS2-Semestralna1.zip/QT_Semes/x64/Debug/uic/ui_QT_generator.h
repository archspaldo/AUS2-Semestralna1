/********************************************************************************
** Form generated from reading UI file 'QT_generator.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_GENERATOR_H
#define UI_QT_GENERATOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_Dialog_generator
{
public:
    QGridLayout *gridLayout;
    QSpinBox *spinBox_5;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QSpinBox *spinBox_3;
    QSpinBox *spinBox_4;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QHBoxLayout *hboxLayout;
    QSpacerItem *spacerItem;
    QPushButton *okButton;
    QPushButton *cancelButton;
    QSpacerItem *verticalSpacer;

    void setupUi(QDialog *Dialog_generator)
    {
        if (Dialog_generator->objectName().isEmpty())
            Dialog_generator->setObjectName(QString::fromUtf8("Dialog_generator"));
        Dialog_generator->resize(474, 413);
        gridLayout = new QGridLayout(Dialog_generator);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        spinBox_5 = new QSpinBox(Dialog_generator);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(spinBox_5->sizePolicy().hasHeightForWidth());
        spinBox_5->setSizePolicy(sizePolicy);
        spinBox_5->setMinimum(1);
        spinBox_5->setMaximum(1000);

        gridLayout->addWidget(spinBox_5, 4, 1, 1, 1);

        spinBox = new QSpinBox(Dialog_generator);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setMinimum(1);
        spinBox->setMaximum(100000);

        gridLayout->addWidget(spinBox, 0, 1, 1, 1);

        spinBox_2 = new QSpinBox(Dialog_generator);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setMinimum(1);
        spinBox_2->setMaximum(1000);

        gridLayout->addWidget(spinBox_2, 1, 1, 1, 1);

        spinBox_3 = new QSpinBox(Dialog_generator);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        spinBox_3->setMinimum(1);
        spinBox_3->setMaximum(1000);

        gridLayout->addWidget(spinBox_3, 2, 1, 1, 1);

        spinBox_4 = new QSpinBox(Dialog_generator);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setMinimum(1);
        spinBox_4->setMaximum(1000);

        gridLayout->addWidget(spinBox_4, 3, 1, 1, 1);

        label = new QLabel(Dialog_generator);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(Dialog_generator);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        label_3 = new QLabel(Dialog_generator);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        label_4 = new QLabel(Dialog_generator);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        label_5 = new QLabel(Dialog_generator);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 1);

        hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout->setSpacing(6);
#endif
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        spacerItem = new QSpacerItem(131, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        okButton = new QPushButton(Dialog_generator);
        okButton->setObjectName(QString::fromUtf8("okButton"));

        hboxLayout->addWidget(okButton);

        cancelButton = new QPushButton(Dialog_generator);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        hboxLayout->addWidget(cancelButton);


        gridLayout->addLayout(hboxLayout, 6, 0, 1, 2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 5, 0, 1, 2);

        QWidget::setTabOrder(spinBox, spinBox_2);
        QWidget::setTabOrder(spinBox_2, spinBox_3);
        QWidget::setTabOrder(spinBox_3, spinBox_4);
        QWidget::setTabOrder(spinBox_4, spinBox_5);
        QWidget::setTabOrder(spinBox_5, okButton);
        QWidget::setTabOrder(okButton, cancelButton);

        retranslateUi(Dialog_generator);
        QObject::connect(okButton, &QPushButton::clicked, Dialog_generator, qOverload<>(&QDialog::accept));
        QObject::connect(cancelButton, &QPushButton::clicked, Dialog_generator, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(Dialog_generator);
    } // setupUi

    void retranslateUi(QDialog *Dialog_generator)
    {
        Dialog_generator->setWindowTitle(QCoreApplication::translate("Dialog_generator", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Dialog_generator", "Po\304\215et os\303\264b", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog_generator", "Po\304\215et testov pre osobu", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog_generator", "Po\304\215et krajov", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog_generator", "Po\304\215et okresov", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog_generator", "Po\304\215et odbern\303\275ch miest", nullptr));
        okButton->setText(QCoreApplication::translate("Dialog_generator", "OK", nullptr));
        cancelButton->setText(QCoreApplication::translate("Dialog_generator", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_generator: public Ui_Dialog_generator {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_GENERATOR_H
