/********************************************************************************
** Form generated from reading UI file 'QT_Semes.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_SEMES_H
#define UI_QT_SEMES_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QT_SemesClass
{
public:
    QAction *actionGenerator;
    QAction *actionManu_lne;
    QAction *actionGenerova;
    QAction *actionSlovensko;
    QAction *actionKraj;
    QAction *actionOkres;
    QAction *actionOsoba;
    QAction *actionTest;
    QAction *actionLokality;
    QAction *actionSlovensko_2;
    QAction *actionSlovensko_3;
    QAction *actionKraje;
    QAction *actionOkresy;
    QAction *actionTest_2;
    QAction *actionOsoba_2;
    QAction *actionTest_3;
    QAction *actionImport;
    QAction *actionExport;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QStackedWidget *stackedWidget;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QMenuBar *menuBar;
    QMenu *menuPridat;
    QMenu *menuZobrazi;
    QMenu *menuTester;
    QMenu *menuS_bor;

    void setupUi(QMainWindow *QT_SemesClass)
    {
        if (QT_SemesClass->objectName().isEmpty())
            QT_SemesClass->setObjectName(QString::fromUtf8("QT_SemesClass"));
        QT_SemesClass->resize(1090, 732);
        actionGenerator = new QAction(QT_SemesClass);
        actionGenerator->setObjectName(QString::fromUtf8("actionGenerator"));
        actionManu_lne = new QAction(QT_SemesClass);
        actionManu_lne->setObjectName(QString::fromUtf8("actionManu_lne"));
        actionGenerova = new QAction(QT_SemesClass);
        actionGenerova->setObjectName(QString::fromUtf8("actionGenerova"));
        actionSlovensko = new QAction(QT_SemesClass);
        actionSlovensko->setObjectName(QString::fromUtf8("actionSlovensko"));
        actionKraj = new QAction(QT_SemesClass);
        actionKraj->setObjectName(QString::fromUtf8("actionKraj"));
        actionOkres = new QAction(QT_SemesClass);
        actionOkres->setObjectName(QString::fromUtf8("actionOkres"));
        actionOsoba = new QAction(QT_SemesClass);
        actionOsoba->setObjectName(QString::fromUtf8("actionOsoba"));
        actionTest = new QAction(QT_SemesClass);
        actionTest->setObjectName(QString::fromUtf8("actionTest"));
        actionLokality = new QAction(QT_SemesClass);
        actionLokality->setObjectName(QString::fromUtf8("actionLokality"));
        actionSlovensko_2 = new QAction(QT_SemesClass);
        actionSlovensko_2->setObjectName(QString::fromUtf8("actionSlovensko_2"));
        actionSlovensko_3 = new QAction(QT_SemesClass);
        actionSlovensko_3->setObjectName(QString::fromUtf8("actionSlovensko_3"));
        actionKraje = new QAction(QT_SemesClass);
        actionKraje->setObjectName(QString::fromUtf8("actionKraje"));
        actionOkresy = new QAction(QT_SemesClass);
        actionOkresy->setObjectName(QString::fromUtf8("actionOkresy"));
        actionTest_2 = new QAction(QT_SemesClass);
        actionTest_2->setObjectName(QString::fromUtf8("actionTest_2"));
        actionOsoba_2 = new QAction(QT_SemesClass);
        actionOsoba_2->setObjectName(QString::fromUtf8("actionOsoba_2"));
        actionTest_3 = new QAction(QT_SemesClass);
        actionTest_3->setObjectName(QString::fromUtf8("actionTest_3"));
        actionImport = new QAction(QT_SemesClass);
        actionImport->setObjectName(QString::fromUtf8("actionImport"));
        actionExport = new QAction(QT_SemesClass);
        actionExport->setObjectName(QString::fromUtf8("actionExport"));
        centralWidget = new QWidget(QT_SemesClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setEnabled(true);
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(stackedWidget);

        QT_SemesClass->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(QT_SemesClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        QT_SemesClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QT_SemesClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        QT_SemesClass->setStatusBar(statusBar);
        menuBar = new QMenuBar(QT_SemesClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1090, 22));
        menuPridat = new QMenu(menuBar);
        menuPridat->setObjectName(QString::fromUtf8("menuPridat"));
        menuZobrazi = new QMenu(menuBar);
        menuZobrazi->setObjectName(QString::fromUtf8("menuZobrazi"));
        menuTester = new QMenu(menuBar);
        menuTester->setObjectName(QString::fromUtf8("menuTester"));
        menuS_bor = new QMenu(menuBar);
        menuS_bor->setObjectName(QString::fromUtf8("menuS_bor"));
        QT_SemesClass->setMenuBar(menuBar);

        menuBar->addAction(menuS_bor->menuAction());
        menuBar->addAction(menuPridat->menuAction());
        menuBar->addAction(menuZobrazi->menuAction());
        menuBar->addAction(menuTester->menuAction());
        menuPridat->addAction(actionOsoba_2);
        menuPridat->addAction(actionTest_3);
        menuPridat->addSeparator();
        menuPridat->addAction(actionGenerator);
        menuZobrazi->addAction(actionOsoba);
        menuZobrazi->addAction(actionTest);
        menuZobrazi->addAction(actionLokality);
        menuTester->addAction(actionTest_2);
        menuS_bor->addAction(actionImport);
        menuS_bor->addAction(actionExport);

        retranslateUi(QT_SemesClass);

        stackedWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(QT_SemesClass);
    } // setupUi

    void retranslateUi(QMainWindow *QT_SemesClass)
    {
        QT_SemesClass->setWindowTitle(QCoreApplication::translate("QT_SemesClass", "QT_Semes", nullptr));
        actionGenerator->setText(QCoreApplication::translate("QT_SemesClass", "Gener\303\241tor", nullptr));
        actionManu_lne->setText(QCoreApplication::translate("QT_SemesClass", "Manu\303\241lne", nullptr));
        actionGenerova->setText(QCoreApplication::translate("QT_SemesClass", "Generova\305\245", nullptr));
        actionSlovensko->setText(QCoreApplication::translate("QT_SemesClass", "Slovensko", nullptr));
        actionKraj->setText(QCoreApplication::translate("QT_SemesClass", "Kraj", nullptr));
        actionOkres->setText(QCoreApplication::translate("QT_SemesClass", "Okres", nullptr));
        actionOsoba->setText(QCoreApplication::translate("QT_SemesClass", "Osoba", nullptr));
        actionTest->setText(QCoreApplication::translate("QT_SemesClass", "Test", nullptr));
        actionLokality->setText(QCoreApplication::translate("QT_SemesClass", "Lokality", nullptr));
        actionSlovensko_2->setText(QCoreApplication::translate("QT_SemesClass", "Slovensko", nullptr));
        actionSlovensko_3->setText(QCoreApplication::translate("QT_SemesClass", "Slovensko", nullptr));
        actionKraje->setText(QCoreApplication::translate("QT_SemesClass", "Kraje", nullptr));
        actionOkresy->setText(QCoreApplication::translate("QT_SemesClass", "Okresy", nullptr));
        actionTest_2->setText(QCoreApplication::translate("QT_SemesClass", "Test \305\241trukt\303\272ry", nullptr));
        actionOsoba_2->setText(QCoreApplication::translate("QT_SemesClass", "Osoba", nullptr));
        actionTest_3->setText(QCoreApplication::translate("QT_SemesClass", "Test", nullptr));
        actionImport->setText(QCoreApplication::translate("QT_SemesClass", "Import", nullptr));
        actionExport->setText(QCoreApplication::translate("QT_SemesClass", "Export", nullptr));
        menuPridat->setTitle(QCoreApplication::translate("QT_SemesClass", "Prida\305\245", nullptr));
        menuZobrazi->setTitle(QCoreApplication::translate("QT_SemesClass", "Zobrazi\305\245", nullptr));
        menuTester->setTitle(QCoreApplication::translate("QT_SemesClass", "Tester", nullptr));
        menuS_bor->setTitle(QCoreApplication::translate("QT_SemesClass", "S\303\272bor", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QT_SemesClass: public Ui_QT_SemesClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_SEMES_H
