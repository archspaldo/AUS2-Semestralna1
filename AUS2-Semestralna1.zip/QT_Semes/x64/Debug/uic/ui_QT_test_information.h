/********************************************************************************
** Form generated from reading UI file 'QT_test_information.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_TEST_INFORMATION_H
#define UI_QT_TEST_INFORMATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form_test_information
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_7;
    QLabel *label;
    QLabel *label_6;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_2;
    QLabel *label_7;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_8;
    QLabel *label_2;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_6;
    QLabel *label_5;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_5;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *Form_test_information)
    {
        if (Form_test_information->objectName().isEmpty())
            Form_test_information->setObjectName(QString::fromUtf8("Form_test_information"));
        Form_test_information->resize(766, 504);
        gridLayout = new QGridLayout(Form_test_information);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lineEdit_7 = new QLineEdit(Form_test_information);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setReadOnly(true);

        gridLayout->addWidget(lineEdit_7, 6, 1, 1, 1);

        label = new QLabel(Form_test_information);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_6 = new QLabel(Form_test_information);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 5, 0, 1, 1);

        lineEdit_4 = new QLineEdit(Form_test_information);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setReadOnly(true);

        gridLayout->addWidget(lineEdit_4, 3, 1, 1, 1);

        lineEdit_2 = new QLineEdit(Form_test_information);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setReadOnly(true);

        gridLayout->addWidget(lineEdit_2, 1, 1, 1, 1);

        label_7 = new QLabel(Form_test_information);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 6, 0, 1, 1);

        lineEdit_3 = new QLineEdit(Form_test_information);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setReadOnly(true);

        gridLayout->addWidget(lineEdit_3, 2, 1, 1, 1);

        label_3 = new QLabel(Form_test_information);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        label_4 = new QLabel(Form_test_information);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        label_8 = new QLabel(Form_test_information);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 7, 0, 1, 1);

        label_2 = new QLabel(Form_test_information);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        pushButton = new QPushButton(Form_test_information);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 8, 0, 1, 2);

        lineEdit = new QLineEdit(Form_test_information);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setReadOnly(true);

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        lineEdit_6 = new QLineEdit(Form_test_information);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setReadOnly(true);

        gridLayout->addWidget(lineEdit_6, 5, 1, 1, 1);

        label_5 = new QLabel(Form_test_information);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 1);

        lineEdit_8 = new QLineEdit(Form_test_information);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setReadOnly(true);

        gridLayout->addWidget(lineEdit_8, 7, 1, 1, 1);

        lineEdit_5 = new QLineEdit(Form_test_information);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setReadOnly(true);

        gridLayout->addWidget(lineEdit_5, 4, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 9, 0, 1, 2);


        retranslateUi(Form_test_information);

        QMetaObject::connectSlotsByName(Form_test_information);
    } // setupUi

    void retranslateUi(QWidget *Form_test_information)
    {
        Form_test_information->setWindowTitle(QCoreApplication::translate("Form_test_information", "Form", nullptr));
        label->setText(QCoreApplication::translate("Form_test_information", "Rodn\303\251 \304\215\303\255slo", nullptr));
        label_6->setText(QCoreApplication::translate("Form_test_information", "Okres", nullptr));
        label_7->setText(QCoreApplication::translate("Form_test_information", "Testovacia stanica", nullptr));
        label_3->setText(QCoreApplication::translate("Form_test_information", "V\303\275sledok", nullptr));
        label_4->setText(QCoreApplication::translate("Form_test_information", "D\303\241tum testovania", nullptr));
        label_8->setText(QCoreApplication::translate("Form_test_information", "Koment\303\241r", nullptr));
        label_2->setText(QCoreApplication::translate("Form_test_information", "UUID", nullptr));
        pushButton->setText(QCoreApplication::translate("Form_test_information", "Vymaza\305\245 test", nullptr));
        label_5->setText(QCoreApplication::translate("Form_test_information", "Kraj", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form_test_information: public Ui_Form_test_information {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_TEST_INFORMATION_H
