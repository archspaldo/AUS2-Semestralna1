/********************************************************************************
** Form generated from reading UI file 'QT_test_view.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_TEST_VIEW_H
#define UI_QT_TEST_VIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form_test_view
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QListView *listView_2;

    void setupUi(QWidget *Form_test_view)
    {
        if (Form_test_view->objectName().isEmpty())
            Form_test_view->setObjectName(QString::fromUtf8("Form_test_view"));
        Form_test_view->resize(782, 500);
        gridLayout = new QGridLayout(Form_test_view);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lineEdit = new QLineEdit(Form_test_view);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout->addWidget(lineEdit, 0, 0, 1, 1);

        pushButton = new QPushButton(Form_test_view);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 0, 1, 1, 1);

        pushButton_3 = new QPushButton(Form_test_view);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        gridLayout->addWidget(pushButton_3, 0, 2, 1, 1);

        listView_2 = new QListView(Form_test_view);
        listView_2->setObjectName(QString::fromUtf8("listView_2"));

        gridLayout->addWidget(listView_2, 1, 0, 1, 3);


        retranslateUi(Form_test_view);

        QMetaObject::connectSlotsByName(Form_test_view);
    } // setupUi

    void retranslateUi(QWidget *Form_test_view)
    {
        Form_test_view->setWindowTitle(QCoreApplication::translate("Form_test_view", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("Form_test_view", "Filtrova\305\245", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Form_test_view", "Reset", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form_test_view: public Ui_Form_test_view {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_TEST_VIEW_H
