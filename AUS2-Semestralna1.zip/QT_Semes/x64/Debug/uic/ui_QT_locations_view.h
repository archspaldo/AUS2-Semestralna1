/********************************************************************************
** Form generated from reading UI file 'QT_locations_view.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_LOCATIONS_VIEW_H
#define UI_QT_LOCATIONS_VIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form_location_view
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QComboBox *comboBox;
    QDateTimeEdit *dateTimeEdit;
    QPushButton *pushButton;
    QLabel *label_4;
    QLabel *label_3;
    QDateTimeEdit *dateTimeEdit_2;
    QPushButton *pushButton_3;
    QLabel *label_2;
    QSpinBox *spinBox;
    QComboBox *comboBox_2;
    QCheckBox *checkBox;
    QStackedWidget *stackedWidget;
    QTableView *tableView;

    void setupUi(QWidget *Form_location_view)
    {
        if (Form_location_view->objectName().isEmpty())
            Form_location_view->setObjectName(QString::fromUtf8("Form_location_view"));
        Form_location_view->resize(665, 511);
        gridLayout = new QGridLayout(Form_location_view);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(Form_location_view);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 1, 0, 1, 1);

        comboBox = new QComboBox(Form_location_view);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(comboBox->sizePolicy().hasHeightForWidth());
        comboBox->setSizePolicy(sizePolicy);

        gridLayout->addWidget(comboBox, 1, 1, 1, 2);

        dateTimeEdit = new QDateTimeEdit(Form_location_view);
        dateTimeEdit->setObjectName(QString::fromUtf8("dateTimeEdit"));
        sizePolicy.setHeightForWidth(dateTimeEdit->sizePolicy().hasHeightForWidth());
        dateTimeEdit->setSizePolicy(sizePolicy);

        gridLayout->addWidget(dateTimeEdit, 5, 1, 1, 2);

        pushButton = new QPushButton(Form_location_view);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 5, 3, 1, 1);

        label_4 = new QLabel(Form_location_view);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 6, 0, 1, 1);

        label_3 = new QLabel(Form_location_view);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 5, 0, 1, 1);

        dateTimeEdit_2 = new QDateTimeEdit(Form_location_view);
        dateTimeEdit_2->setObjectName(QString::fromUtf8("dateTimeEdit_2"));
        sizePolicy.setHeightForWidth(dateTimeEdit_2->sizePolicy().hasHeightForWidth());
        dateTimeEdit_2->setSizePolicy(sizePolicy);

        gridLayout->addWidget(dateTimeEdit_2, 6, 1, 1, 2);

        pushButton_3 = new QPushButton(Form_location_view);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        gridLayout->addWidget(pushButton_3, 5, 4, 1, 1);

        label_2 = new QLabel(Form_location_view);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 3, 0, 1, 1);

        spinBox = new QSpinBox(Form_location_view);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setEnabled(false);
        sizePolicy.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
        spinBox->setSizePolicy(sizePolicy);

        gridLayout->addWidget(spinBox, 3, 1, 1, 2);

        comboBox_2 = new QComboBox(Form_location_view);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        sizePolicy.setHeightForWidth(comboBox_2->sizePolicy().hasHeightForWidth());
        comboBox_2->setSizePolicy(sizePolicy);

        gridLayout->addWidget(comboBox_2, 0, 0, 1, 5);

        checkBox = new QCheckBox(Form_location_view);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        sizePolicy.setHeightForWidth(checkBox->sizePolicy().hasHeightForWidth());
        checkBox->setSizePolicy(sizePolicy);

        gridLayout->addWidget(checkBox, 7, 2, 1, 1);

        stackedWidget = new QStackedWidget(Form_location_view);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(stackedWidget, 0, 5, 9, 1);

        tableView = new QTableView(Form_location_view);
        tableView->setObjectName(QString::fromUtf8("tableView"));

        gridLayout->addWidget(tableView, 8, 0, 1, 5);


        retranslateUi(Form_location_view);

        comboBox->setCurrentIndex(3);
        stackedWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(Form_location_view);
    } // setupUi

    void retranslateUi(QWidget *Form_location_view)
    {
        Form_location_view->setWindowTitle(QCoreApplication::translate("Form_location_view", "Form", nullptr));
        label->setText(QCoreApplication::translate("Form_location_view", "Lokalita", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("Form_location_view", "Stanica", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("Form_location_view", "Kraj", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("Form_location_view", "Okres", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("Form_location_view", "Celkovo", nullptr));

        pushButton->setText(QCoreApplication::translate("Form_location_view", "Filtrova\305\245", nullptr));
        label_4->setText(QCoreApplication::translate("Form_location_view", "D\303\241tum do", nullptr));
        label_3->setText(QCoreApplication::translate("Form_location_view", "D\303\241tum od", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Form_location_view", "Reset", nullptr));
        label_2->setText(QCoreApplication::translate("Form_location_view", "ID lokality", nullptr));
        comboBox_2->setItemText(0, QCoreApplication::translate("Form_location_view", "Osoby", nullptr));
        comboBox_2->setItemText(1, QCoreApplication::translate("Form_location_view", "Testy", nullptr));
        comboBox_2->setItemText(2, QCoreApplication::translate("Form_location_view", "Sumariz\303\241cia", nullptr));
        comboBox_2->setItemText(3, QCoreApplication::translate("Form_location_view", "Testy pod\304\276a kraja", nullptr));

        checkBox->setText(QCoreApplication::translate("Form_location_view", "Len pozit\303\255vni", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form_location_view: public Ui_Form_location_view {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_LOCATIONS_VIEW_H
