/********************************************************************************
** Form generated from reading UI file 'QT_person_information.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_PERSON_INFORMATION_H
#define UI_QT_PERSON_INFORMATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form_person_information
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButton;
    QLineEdit *lineEdit_2;
    QLabel *label_3;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_3;
    QLabel *label_4;
    QLabel *label_2;
    QLabel *label;
    QListView *listView;

    void setupUi(QWidget *Form_person_information)
    {
        if (Form_person_information->objectName().isEmpty())
            Form_person_information->setObjectName(QString::fromUtf8("Form_person_information"));
        Form_person_information->resize(513, 462);
        gridLayout = new QGridLayout(Form_person_information);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        pushButton = new QPushButton(Form_person_information);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 4, 0, 1, 2);

        lineEdit_2 = new QLineEdit(Form_person_information);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setReadOnly(true);

        gridLayout->addWidget(lineEdit_2, 1, 1, 1, 1);

        label_3 = new QLabel(Form_person_information);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        lineEdit = new QLineEdit(Form_person_information);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setReadOnly(true);

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        lineEdit_4 = new QLineEdit(Form_person_information);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setReadOnly(true);

        gridLayout->addWidget(lineEdit_4, 3, 1, 1, 1);

        lineEdit_3 = new QLineEdit(Form_person_information);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setReadOnly(true);

        gridLayout->addWidget(lineEdit_3, 2, 1, 1, 1);

        label_4 = new QLabel(Form_person_information);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        label_2 = new QLabel(Form_person_information);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        label = new QLabel(Form_person_information);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        listView = new QListView(Form_person_information);
        listView->setObjectName(QString::fromUtf8("listView"));

        gridLayout->addWidget(listView, 5, 0, 1, 2);


        retranslateUi(Form_person_information);

        QMetaObject::connectSlotsByName(Form_person_information);
    } // setupUi

    void retranslateUi(QWidget *Form_person_information)
    {
        Form_person_information->setWindowTitle(QCoreApplication::translate("Form_person_information", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("Form_person_information", "Vymaza\305\245 osobu", nullptr));
        label_3->setText(QCoreApplication::translate("Form_person_information", "Priezvisko", nullptr));
        label_4->setText(QCoreApplication::translate("Form_person_information", "D\303\241tum narodenia", nullptr));
        label_2->setText(QCoreApplication::translate("Form_person_information", "Meno", nullptr));
        label->setText(QCoreApplication::translate("Form_person_information", "Rodn\303\251 \304\215\303\255slo", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form_person_information: public Ui_Form_person_information {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_PERSON_INFORMATION_H
