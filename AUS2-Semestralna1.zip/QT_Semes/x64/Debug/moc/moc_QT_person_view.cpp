/****************************************************************************
** Meta object code from reading C++ file 'QT_person_view.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../QT_person_view.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QT_person_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QPersonView_t {
    const uint offsetsAndSize[20];
    char stringdata0[166];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_QPersonView_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_QPersonView_t qt_meta_stringdata_QPersonView = {
    {
QT_MOC_LITERAL(0, 11), // "QPersonView"
QT_MOC_LITERAL(12, 18), // "test_doubleclicked"
QT_MOC_LITERAL(31, 0), // ""
QT_MOC_LITERAL(32, 19), // "QAbstractItemModel*"
QT_MOC_LITERAL(52, 24), // "on_filter_button_clicked"
QT_MOC_LITERAL(77, 23), // "on_reset_button_clicked"
QT_MOC_LITERAL(101, 17), // "on_person_clicked"
QT_MOC_LITERAL(119, 17), // "on_person_removed"
QT_MOC_LITERAL(137, 22), // "on_test_double_clicked"
QT_MOC_LITERAL(160, 5) // "model"

    },
    "QPersonView\0test_doubleclicked\0\0"
    "QAbstractItemModel*\0on_filter_button_clicked\0"
    "on_reset_button_clicked\0on_person_clicked\0"
    "on_person_removed\0on_test_double_clicked\0"
    "model"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QPersonView[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   62,    2, 0x06,    1 /* Public */,
       1,    0,   65,    2, 0x26,    3 /* Public | MethodCloned */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,   66,    2, 0x08,    4 /* Private */,
       5,    0,   67,    2, 0x08,    5 /* Private */,
       6,    0,   68,    2, 0x08,    6 /* Private */,
       7,    0,   69,    2, 0x08,    7 /* Private */,
       8,    1,   70,    2, 0x08,    8 /* Private */,
       8,    0,   73,    2, 0x28,   10 /* Private | MethodCloned */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3,    9,
    QMetaType::Void,

       0        // eod
};

void QPersonView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QPersonView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->test_doubleclicked((*reinterpret_cast< QAbstractItemModel*(*)>(_a[1]))); break;
        case 1: _t->test_doubleclicked(); break;
        case 2: _t->on_filter_button_clicked(); break;
        case 3: _t->on_reset_button_clicked(); break;
        case 4: _t->on_person_clicked(); break;
        case 5: _t->on_person_removed(); break;
        case 6: _t->on_test_double_clicked((*reinterpret_cast< QAbstractItemModel*(*)>(_a[1]))); break;
        case 7: _t->on_test_double_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractItemModel* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractItemModel* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QPersonView::*)(QAbstractItemModel * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QPersonView::test_doubleclicked)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject QPersonView::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_QPersonView.offsetsAndSize,
    qt_meta_data_QPersonView,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_QPersonView_t
, QtPrivate::TypeAndForceComplete<QPersonView, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QAbstractItemModel *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QAbstractItemModel *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *QPersonView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QPersonView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QPersonView.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int QPersonView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void QPersonView::test_doubleclicked(QAbstractItemModel * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
