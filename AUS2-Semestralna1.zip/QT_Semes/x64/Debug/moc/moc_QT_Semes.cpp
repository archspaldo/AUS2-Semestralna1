/****************************************************************************
** Meta object code from reading C++ file 'QT_Semes.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../QT_Semes.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QT_Semes.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QT_Semes_t {
    const uint offsetsAndSize[56];
    char stringdata0[488];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_QT_Semes_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_QT_Semes_t qt_meta_stringdata_QT_Semes = {
    {
QT_MOC_LITERAL(0, 8), // "QT_Semes"
QT_MOC_LITERAL(9, 21), // "onButtonClickedTester"
QT_MOC_LITERAL(31, 0), // ""
QT_MOC_LITERAL(32, 29), // "onButtonClickedGeneratePeople"
QT_MOC_LITERAL(62, 24), // "onButtonClickedAddPerson"
QT_MOC_LITERAL(87, 22), // "onButtonClickedAddTest"
QT_MOC_LITERAL(110, 16), // "onActionZobrazit"
QT_MOC_LITERAL(127, 19), // "onActionPridatOsMan"
QT_MOC_LITERAL(147, 19), // "onActionPridatTsMan"
QT_MOC_LITERAL(167, 17), // "onActionPridatGen"
QT_MOC_LITERAL(185, 14), // "onActionTest_2"
QT_MOC_LITERAL(200, 16), // "onSelectedPerson"
QT_MOC_LITERAL(217, 14), // "onSelectedTest"
QT_MOC_LITERAL(232, 19), // "onDoubleClickedTest"
QT_MOC_LITERAL(252, 18), // "onClickedOsobaView"
QT_MOC_LITERAL(271, 17), // "onClickedTestView"
QT_MOC_LITERAL(289, 18), // "onClickedOkresView"
QT_MOC_LITERAL(308, 17), // "onClickedKrajView"
QT_MOC_LITERAL(326, 22), // "onClickedSlovenskoView"
QT_MOC_LITERAL(349, 20), // "onClickedStanicaView"
QT_MOC_LITERAL(370, 14), // "onFilterPerson"
QT_MOC_LITERAL(385, 13), // "onResetPerson"
QT_MOC_LITERAL(399, 12), // "onFilterTest"
QT_MOC_LITERAL(412, 11), // "onResetTest"
QT_MOC_LITERAL(424, 16), // "onFilterDistrict"
QT_MOC_LITERAL(441, 15), // "onResetDistrict"
QT_MOC_LITERAL(457, 15), // "onFilterStation"
QT_MOC_LITERAL(473, 14) // "onResetStation"

    },
    "QT_Semes\0onButtonClickedTester\0\0"
    "onButtonClickedGeneratePeople\0"
    "onButtonClickedAddPerson\0"
    "onButtonClickedAddTest\0onActionZobrazit\0"
    "onActionPridatOsMan\0onActionPridatTsMan\0"
    "onActionPridatGen\0onActionTest_2\0"
    "onSelectedPerson\0onSelectedTest\0"
    "onDoubleClickedTest\0onClickedOsobaView\0"
    "onClickedTestView\0onClickedOkresView\0"
    "onClickedKrajView\0onClickedSlovenskoView\0"
    "onClickedStanicaView\0onFilterPerson\0"
    "onResetPerson\0onFilterTest\0onResetTest\0"
    "onFilterDistrict\0onResetDistrict\0"
    "onFilterStation\0onResetStation"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QT_Semes[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  170,    2, 0x08,    1 /* Private */,
       3,    0,  171,    2, 0x08,    2 /* Private */,
       4,    0,  172,    2, 0x08,    3 /* Private */,
       5,    0,  173,    2, 0x08,    4 /* Private */,
       6,    0,  174,    2, 0x08,    5 /* Private */,
       7,    0,  175,    2, 0x08,    6 /* Private */,
       8,    0,  176,    2, 0x08,    7 /* Private */,
       9,    0,  177,    2, 0x08,    8 /* Private */,
      10,    0,  178,    2, 0x08,    9 /* Private */,
      11,    0,  179,    2, 0x08,   10 /* Private */,
      12,    0,  180,    2, 0x08,   11 /* Private */,
      13,    0,  181,    2, 0x08,   12 /* Private */,
      14,    0,  182,    2, 0x08,   13 /* Private */,
      15,    0,  183,    2, 0x08,   14 /* Private */,
      16,    0,  184,    2, 0x08,   15 /* Private */,
      17,    0,  185,    2, 0x08,   16 /* Private */,
      18,    0,  186,    2, 0x08,   17 /* Private */,
      19,    0,  187,    2, 0x08,   18 /* Private */,
      20,    0,  188,    2, 0x08,   19 /* Private */,
      21,    0,  189,    2, 0x08,   20 /* Private */,
      22,    0,  190,    2, 0x08,   21 /* Private */,
      23,    0,  191,    2, 0x08,   22 /* Private */,
      24,    0,  192,    2, 0x08,   23 /* Private */,
      25,    0,  193,    2, 0x08,   24 /* Private */,
      26,    0,  194,    2, 0x08,   25 /* Private */,
      27,    0,  195,    2, 0x08,   26 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void QT_Semes::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QT_Semes *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onButtonClickedTester(); break;
        case 1: _t->onButtonClickedGeneratePeople(); break;
        case 2: _t->onButtonClickedAddPerson(); break;
        case 3: _t->onButtonClickedAddTest(); break;
        case 4: _t->onActionZobrazit(); break;
        case 5: _t->onActionPridatOsMan(); break;
        case 6: _t->onActionPridatTsMan(); break;
        case 7: _t->onActionPridatGen(); break;
        case 8: _t->onActionTest_2(); break;
        case 9: _t->onSelectedPerson(); break;
        case 10: _t->onSelectedTest(); break;
        case 11: _t->onDoubleClickedTest(); break;
        case 12: _t->onClickedOsobaView(); break;
        case 13: _t->onClickedTestView(); break;
        case 14: _t->onClickedOkresView(); break;
        case 15: _t->onClickedKrajView(); break;
        case 16: _t->onClickedSlovenskoView(); break;
        case 17: _t->onClickedStanicaView(); break;
        case 18: _t->onFilterPerson(); break;
        case 19: _t->onResetPerson(); break;
        case 20: _t->onFilterTest(); break;
        case 21: _t->onResetTest(); break;
        case 22: _t->onFilterDistrict(); break;
        case 23: _t->onResetDistrict(); break;
        case 24: _t->onFilterStation(); break;
        case 25: _t->onResetStation(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject QT_Semes::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_QT_Semes.offsetsAndSize,
    qt_meta_data_QT_Semes,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_QT_Semes_t
, QtPrivate::TypeAndForceComplete<QT_Semes, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *QT_Semes::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QT_Semes::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QT_Semes.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int QT_Semes::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 26;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
