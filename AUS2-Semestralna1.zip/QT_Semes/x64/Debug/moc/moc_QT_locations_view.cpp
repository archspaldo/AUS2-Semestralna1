/****************************************************************************
** Meta object code from reading C++ file 'QT_locations_view.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../QT_locations_view.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QT_locations_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QLocationView_t {
    const uint offsetsAndSize[26];
    char stringdata0[221];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_QLocationView_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_QLocationView_t qt_meta_stringdata_QLocationView = {
    {
QT_MOC_LITERAL(0, 13), // "QLocationView"
QT_MOC_LITERAL(14, 18), // "test_doubleclicked"
QT_MOC_LITERAL(33, 0), // ""
QT_MOC_LITERAL(34, 19), // "QAbstractItemModel*"
QT_MOC_LITERAL(54, 24), // "on_filter_button_clicked"
QT_MOC_LITERAL(79, 23), // "on_reset_button_clicked"
QT_MOC_LITERAL(103, 20), // "on_location_selected"
QT_MOC_LITERAL(124, 17), // "on_model_selected"
QT_MOC_LITERAL(142, 15), // "on_item_clicked"
QT_MOC_LITERAL(158, 17), // "on_person_removed"
QT_MOC_LITERAL(176, 15), // "on_test_removed"
QT_MOC_LITERAL(192, 22), // "on_test_double_clicked"
QT_MOC_LITERAL(215, 5) // "model"

    },
    "QLocationView\0test_doubleclicked\0\0"
    "QAbstractItemModel*\0on_filter_button_clicked\0"
    "on_reset_button_clicked\0on_location_selected\0"
    "on_model_selected\0on_item_clicked\0"
    "on_person_removed\0on_test_removed\0"
    "on_test_double_clicked\0model"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QLocationView[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   80,    2, 0x06,    1 /* Public */,
       1,    0,   83,    2, 0x26,    3 /* Public | MethodCloned */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,   84,    2, 0x08,    4 /* Private */,
       5,    0,   85,    2, 0x08,    5 /* Private */,
       6,    0,   86,    2, 0x08,    6 /* Private */,
       7,    0,   87,    2, 0x08,    7 /* Private */,
       8,    0,   88,    2, 0x08,    8 /* Private */,
       9,    0,   89,    2, 0x08,    9 /* Private */,
      10,    0,   90,    2, 0x08,   10 /* Private */,
      11,    1,   91,    2, 0x08,   11 /* Private */,
      11,    0,   94,    2, 0x28,   13 /* Private | MethodCloned */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3,   12,
    QMetaType::Void,

       0        // eod
};

void QLocationView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QLocationView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->test_doubleclicked((*reinterpret_cast< QAbstractItemModel*(*)>(_a[1]))); break;
        case 1: _t->test_doubleclicked(); break;
        case 2: _t->on_filter_button_clicked(); break;
        case 3: _t->on_reset_button_clicked(); break;
        case 4: _t->on_location_selected(); break;
        case 5: _t->on_model_selected(); break;
        case 6: _t->on_item_clicked(); break;
        case 7: _t->on_person_removed(); break;
        case 8: _t->on_test_removed(); break;
        case 9: _t->on_test_double_clicked((*reinterpret_cast< QAbstractItemModel*(*)>(_a[1]))); break;
        case 10: _t->on_test_double_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractItemModel* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractItemModel* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QLocationView::*)(QAbstractItemModel * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QLocationView::test_doubleclicked)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject QLocationView::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_QLocationView.offsetsAndSize,
    qt_meta_data_QLocationView,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_QLocationView_t
, QtPrivate::TypeAndForceComplete<QLocationView, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QAbstractItemModel *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QAbstractItemModel *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *QLocationView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QLocationView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QLocationView.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int QLocationView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void QLocationView::test_doubleclicked(QAbstractItemModel * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
