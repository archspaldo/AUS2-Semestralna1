/********************************************************************************
** Form generated from reading UI file 'QT_location_information.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_LOCATION_INFORMATION_H
#define UI_QT_LOCATION_INFORMATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form_location_information
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *Form_location_information)
    {
        if (Form_location_information->objectName().isEmpty())
            Form_location_information->setObjectName(QString::fromUtf8("Form_location_information"));
        Form_location_information->resize(607, 506);
        gridLayout = new QGridLayout(Form_location_information);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lineEdit = new QLineEdit(Form_location_information);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setReadOnly(true);

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        label = new QLabel(Form_location_information);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(Form_location_information);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        lineEdit_2 = new QLineEdit(Form_location_information);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setReadOnly(true);

        gridLayout->addWidget(lineEdit_2, 1, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 2, 1, 1, 1);


        retranslateUi(Form_location_information);

        QMetaObject::connectSlotsByName(Form_location_information);
    } // setupUi

    void retranslateUi(QWidget *Form_location_information)
    {
        Form_location_information->setWindowTitle(QCoreApplication::translate("Form_location_information", "Form", nullptr));
        label->setText(QCoreApplication::translate("Form_location_information", "ID", nullptr));
        label_2->setText(QCoreApplication::translate("Form_location_information", "Po\304\215et pozit\303\255vn\303\275ch", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form_location_information: public Ui_Form_location_information {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_LOCATION_INFORMATION_H
