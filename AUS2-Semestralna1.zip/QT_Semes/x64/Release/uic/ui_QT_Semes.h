/********************************************************************************
** Form generated from reading UI file 'QT_Semes.ui'
**
** Created by: Qt User Interface Compiler version 6.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_SEMES_H
#define UI_QT_SEMES_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QT_SemesClass
{
public:
    QAction *actionGenerator;
    QAction *actionManu_lne;
    QAction *actionGenerova;
    QAction *actionSlovensko;
    QAction *actionKraj;
    QAction *actionOkres;
    QAction *actionOsoba;
    QAction *actionTest;
    QAction *actionTestovacie_Stanice;
    QAction *actionSlovensko_2;
    QAction *actionSlovensko_3;
    QAction *actionKraje;
    QAction *actionOkresy;
    QAction *actionTest_2;
    QAction *actionOsoba_2;
    QAction *actionTest_3;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QGridLayout *gridLayout_5;
    QGridLayout *gridLayout_3;
    QStackedWidget *stackedWidget_4;
    QWidget *page_10;
    QGridLayout *gridLayout_11;
    QListView *listView;
    QWidget *page_11;
    QGridLayout *gridLayout_12;
    QListView *listView_3;
    QStackedWidget *stackedWidget_5;
    QWidget *page_8;
    QGridLayout *gridLayout_8;
    QLineEdit *lineEdit_5;
    QWidget *page_9;
    QGridLayout *gridLayout_9;
    QDateTimeEdit *dateTimeEdit_2;
    QRadioButton *radioButton;
    QDateTimeEdit *dateTimeEdit;
    QSpinBox *spinBox_8;
    QWidget *page_13;
    QGridLayout *gridLayout_16;
    QDateTimeEdit *dateTimeEdit_3;
    QDateTimeEdit *dateTimeEdit_4;
    QSpinBox *spinBox_9;
    QStackedWidget *stackedWidget_2;
    QWidget *page_6;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_2;
    QPushButton *pushButton_6;
    QWidget *page_7;
    QGridLayout *gridLayout_13;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QWidget *page_12;
    QGridLayout *gridLayout_14;
    QPushButton *pushButton_4;
    QPushButton *pushButton_9;
    QWidget *page_14;
    QGridLayout *gridLayout_17;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QGridLayout *gridLayout_7;
    QStackedWidget *stackedWidget_3;
    QWidget *page_4;
    QGridLayout *gridLayout_6;
    QLabel *label_5;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit;
    QLabel *label_4;
    QLineEdit *lineEdit_4;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QListView *listView_2;
    QPushButton *pushButton_3;
    QWidget *page_5;
    QGridLayout *gridLayout_10;
    QLineEdit *lineEdit_14;
    QSpacerItem *verticalSpacer_3;
    QLabel *label_15;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_16;
    QLabel *label_16;
    QLineEdit *lineEdit_17;
    QLabel *label_11;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_11;
    QLabel *label_12;
    QLineEdit *lineEdit_10;
    QLabel *label_17;
    QLabel *label_13;
    QLabel *label_18;
    QLabel *label_14;
    QLineEdit *lineEdit_12;
    QPushButton *pushButton_5;
    QWidget *page_2;
    QGridLayout *gridLayout_15;
    QLabel *label_19;
    QSpinBox *spinBox_3;
    QPushButton *pushButton_10;
    QSpinBox *spinBox_5;
    QLabel *label_7;
    QSpinBox *spinBox_4;
    QLabel *label_9;
    QLabel *label_8;
    QLabel *label_10;
    QSpinBox *spinBox_7;
    QSpinBox *spinBox_6;
    QListWidget *listWidget;
    QWidget *page_3;
    QGridLayout *gridLayout_2;
    QStackedWidget *stackedWidget_6;
    QWidget *page_15;
    QGridLayout *gridLayout_18;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QLabel *label;
    QLabel *label_6;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer_2;
    QWidget *page_17;
    QGridLayout *gridLayout;
    QLabel *label_21;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_18;
    QLabel *label_28;
    QSpacerItem *verticalSpacer;
    QLabel *label_29;
    QPushButton *pushButton_14;
    QLineEdit *lineEdit_19;
    QWidget *page_16;
    QGridLayout *gridLayout_19;
    QLineEdit *lineEdit_7;
    QLabel *label_27;
    QSpacerItem *verticalSpacer_4;
    QSpinBox *spinBox_12;
    QPushButton *pushButton_13;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLineEdit *lineEdit_21;
    QSpinBox *spinBox_13;
    QLabel *label_26;
    QSpinBox *spinBox_11;
    QLineEdit *lineEdit_6;
    QLabel *label_22;
    QDateTimeEdit *dateTimeEdit_5;
    QLabel *label_20;
    QRadioButton *radioButton_2;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QMenuBar *menuBar;
    QMenu *menuPridat;
    QMenu *menuManu_lne;
    QMenu *menuZobrazi;
    QMenu *menuRegion_lne_celky;
    QMenu *menuTester;

    void setupUi(QMainWindow *QT_SemesClass)
    {
        if (QT_SemesClass->objectName().isEmpty())
            QT_SemesClass->setObjectName(QString::fromUtf8("QT_SemesClass"));
        QT_SemesClass->resize(1090, 732);
        actionGenerator = new QAction(QT_SemesClass);
        actionGenerator->setObjectName(QString::fromUtf8("actionGenerator"));
        actionManu_lne = new QAction(QT_SemesClass);
        actionManu_lne->setObjectName(QString::fromUtf8("actionManu_lne"));
        actionGenerova = new QAction(QT_SemesClass);
        actionGenerova->setObjectName(QString::fromUtf8("actionGenerova"));
        actionSlovensko = new QAction(QT_SemesClass);
        actionSlovensko->setObjectName(QString::fromUtf8("actionSlovensko"));
        actionKraj = new QAction(QT_SemesClass);
        actionKraj->setObjectName(QString::fromUtf8("actionKraj"));
        actionOkres = new QAction(QT_SemesClass);
        actionOkres->setObjectName(QString::fromUtf8("actionOkres"));
        actionOsoba = new QAction(QT_SemesClass);
        actionOsoba->setObjectName(QString::fromUtf8("actionOsoba"));
        actionTest = new QAction(QT_SemesClass);
        actionTest->setObjectName(QString::fromUtf8("actionTest"));
        actionTestovacie_Stanice = new QAction(QT_SemesClass);
        actionTestovacie_Stanice->setObjectName(QString::fromUtf8("actionTestovacie_Stanice"));
        actionSlovensko_2 = new QAction(QT_SemesClass);
        actionSlovensko_2->setObjectName(QString::fromUtf8("actionSlovensko_2"));
        actionSlovensko_3 = new QAction(QT_SemesClass);
        actionSlovensko_3->setObjectName(QString::fromUtf8("actionSlovensko_3"));
        actionKraje = new QAction(QT_SemesClass);
        actionKraje->setObjectName(QString::fromUtf8("actionKraje"));
        actionOkresy = new QAction(QT_SemesClass);
        actionOkresy->setObjectName(QString::fromUtf8("actionOkresy"));
        actionTest_2 = new QAction(QT_SemesClass);
        actionTest_2->setObjectName(QString::fromUtf8("actionTest_2"));
        actionOsoba_2 = new QAction(QT_SemesClass);
        actionOsoba_2->setObjectName(QString::fromUtf8("actionOsoba_2"));
        actionTest_3 = new QAction(QT_SemesClass);
        actionTest_3->setObjectName(QString::fromUtf8("actionTest_3"));
        centralWidget = new QWidget(QT_SemesClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setEnabled(true);
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(page->sizePolicy().hasHeightForWidth());
        page->setSizePolicy(sizePolicy1);
        gridLayout_5 = new QGridLayout(page);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setSizeConstraint(QLayout::SetDefaultConstraint);
        stackedWidget_4 = new QStackedWidget(page);
        stackedWidget_4->setObjectName(QString::fromUtf8("stackedWidget_4"));
        page_10 = new QWidget();
        page_10->setObjectName(QString::fromUtf8("page_10"));
        gridLayout_11 = new QGridLayout(page_10);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        gridLayout_11->setContentsMargins(-1, -1, -1, 0);
        listView = new QListView(page_10);
        listView->setObjectName(QString::fromUtf8("listView"));

        gridLayout_11->addWidget(listView, 0, 0, 1, 1);

        stackedWidget_4->addWidget(page_10);
        page_11 = new QWidget();
        page_11->setObjectName(QString::fromUtf8("page_11"));
        gridLayout_12 = new QGridLayout(page_11);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        gridLayout_12->setContentsMargins(-1, -1, -1, 0);
        listView_3 = new QListView(page_11);
        listView_3->setObjectName(QString::fromUtf8("listView_3"));

        gridLayout_12->addWidget(listView_3, 0, 0, 1, 1);

        stackedWidget_4->addWidget(page_11);

        gridLayout_3->addWidget(stackedWidget_4, 4, 0, 1, 4);

        stackedWidget_5 = new QStackedWidget(page);
        stackedWidget_5->setObjectName(QString::fromUtf8("stackedWidget_5"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(stackedWidget_5->sizePolicy().hasHeightForWidth());
        stackedWidget_5->setSizePolicy(sizePolicy2);
        page_8 = new QWidget();
        page_8->setObjectName(QString::fromUtf8("page_8"));
        sizePolicy2.setHeightForWidth(page_8->sizePolicy().hasHeightForWidth());
        page_8->setSizePolicy(sizePolicy2);
        gridLayout_8 = new QGridLayout(page_8);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        lineEdit_5 = new QLineEdit(page_8);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));

        gridLayout_8->addWidget(lineEdit_5, 0, 0, 1, 1);

        stackedWidget_5->addWidget(page_8);
        page_9 = new QWidget();
        page_9->setObjectName(QString::fromUtf8("page_9"));
        sizePolicy2.setHeightForWidth(page_9->sizePolicy().hasHeightForWidth());
        page_9->setSizePolicy(sizePolicy2);
        gridLayout_9 = new QGridLayout(page_9);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        dateTimeEdit_2 = new QDateTimeEdit(page_9);
        dateTimeEdit_2->setObjectName(QString::fromUtf8("dateTimeEdit_2"));

        gridLayout_9->addWidget(dateTimeEdit_2, 2, 0, 1, 1);

        radioButton = new QRadioButton(page_9);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));

        gridLayout_9->addWidget(radioButton, 3, 0, 1, 1);

        dateTimeEdit = new QDateTimeEdit(page_9);
        dateTimeEdit->setObjectName(QString::fromUtf8("dateTimeEdit"));

        gridLayout_9->addWidget(dateTimeEdit, 1, 0, 1, 1);

        spinBox_8 = new QSpinBox(page_9);
        spinBox_8->setObjectName(QString::fromUtf8("spinBox_8"));

        gridLayout_9->addWidget(spinBox_8, 0, 0, 1, 1);

        stackedWidget_5->addWidget(page_9);
        page_13 = new QWidget();
        page_13->setObjectName(QString::fromUtf8("page_13"));
        gridLayout_16 = new QGridLayout(page_13);
        gridLayout_16->setSpacing(6);
        gridLayout_16->setContentsMargins(11, 11, 11, 11);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        dateTimeEdit_3 = new QDateTimeEdit(page_13);
        dateTimeEdit_3->setObjectName(QString::fromUtf8("dateTimeEdit_3"));

        gridLayout_16->addWidget(dateTimeEdit_3, 1, 0, 1, 1);

        dateTimeEdit_4 = new QDateTimeEdit(page_13);
        dateTimeEdit_4->setObjectName(QString::fromUtf8("dateTimeEdit_4"));

        gridLayout_16->addWidget(dateTimeEdit_4, 2, 0, 1, 1);

        spinBox_9 = new QSpinBox(page_13);
        spinBox_9->setObjectName(QString::fromUtf8("spinBox_9"));

        gridLayout_16->addWidget(spinBox_9, 0, 0, 1, 1);

        stackedWidget_5->addWidget(page_13);

        gridLayout_3->addWidget(stackedWidget_5, 0, 0, 4, 2);

        stackedWidget_2 = new QStackedWidget(page);
        stackedWidget_2->setObjectName(QString::fromUtf8("stackedWidget_2"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(stackedWidget_2->sizePolicy().hasHeightForWidth());
        stackedWidget_2->setSizePolicy(sizePolicy3);
        page_6 = new QWidget();
        page_6->setObjectName(QString::fromUtf8("page_6"));
        gridLayout_4 = new QGridLayout(page_6);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        pushButton_2 = new QPushButton(page_6);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy4);

        gridLayout_4->addWidget(pushButton_2, 0, 1, 1, 1);

        pushButton_6 = new QPushButton(page_6);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));

        gridLayout_4->addWidget(pushButton_6, 0, 2, 1, 1);

        stackedWidget_2->addWidget(page_6);
        page_7 = new QWidget();
        page_7->setObjectName(QString::fromUtf8("page_7"));
        gridLayout_13 = new QGridLayout(page_7);
        gridLayout_13->setSpacing(6);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        pushButton_7 = new QPushButton(page_7);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        gridLayout_13->addWidget(pushButton_7, 0, 0, 1, 1);

        pushButton_8 = new QPushButton(page_7);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));

        gridLayout_13->addWidget(pushButton_8, 0, 1, 1, 1);

        stackedWidget_2->addWidget(page_7);
        page_12 = new QWidget();
        page_12->setObjectName(QString::fromUtf8("page_12"));
        gridLayout_14 = new QGridLayout(page_12);
        gridLayout_14->setSpacing(6);
        gridLayout_14->setContentsMargins(11, 11, 11, 11);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        pushButton_4 = new QPushButton(page_12);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        gridLayout_14->addWidget(pushButton_4, 0, 0, 1, 1);

        pushButton_9 = new QPushButton(page_12);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));

        gridLayout_14->addWidget(pushButton_9, 0, 1, 1, 1);

        stackedWidget_2->addWidget(page_12);
        page_14 = new QWidget();
        page_14->setObjectName(QString::fromUtf8("page_14"));
        gridLayout_17 = new QGridLayout(page_14);
        gridLayout_17->setSpacing(6);
        gridLayout_17->setContentsMargins(11, 11, 11, 11);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        pushButton_11 = new QPushButton(page_14);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));

        gridLayout_17->addWidget(pushButton_11, 0, 0, 1, 1);

        pushButton_12 = new QPushButton(page_14);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));

        gridLayout_17->addWidget(pushButton_12, 0, 1, 1, 1);

        stackedWidget_2->addWidget(page_14);

        gridLayout_3->addWidget(stackedWidget_2, 0, 2, 4, 2);

        gridLayout_3->setColumnStretch(0, 1);

        gridLayout_5->addLayout(gridLayout_3, 2, 0, 1, 1);

        gridLayout_7 = new QGridLayout();
        gridLayout_7->setSpacing(6);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        stackedWidget_3 = new QStackedWidget(page);
        stackedWidget_3->setObjectName(QString::fromUtf8("stackedWidget_3"));
        sizePolicy1.setHeightForWidth(stackedWidget_3->sizePolicy().hasHeightForWidth());
        stackedWidget_3->setSizePolicy(sizePolicy1);
        stackedWidget_3->setSizeIncrement(QSize(0, 0));
        page_4 = new QWidget();
        page_4->setObjectName(QString::fromUtf8("page_4"));
        gridLayout_6 = new QGridLayout(page_4);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(9, 9, 9, 0);
        label_5 = new QLabel(page_4);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_6->addWidget(label_5, 3, 0, 1, 1);

        lineEdit_3 = new QLineEdit(page_4);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setReadOnly(true);

        gridLayout_6->addWidget(lineEdit_3, 2, 1, 1, 1);

        lineEdit = new QLineEdit(page_4);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setReadOnly(true);

        gridLayout_6->addWidget(lineEdit, 0, 1, 1, 1);

        label_4 = new QLabel(page_4);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_6->addWidget(label_4, 2, 0, 1, 1);

        lineEdit_4 = new QLineEdit(page_4);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setReadOnly(true);

        gridLayout_6->addWidget(lineEdit_4, 3, 1, 1, 1);

        label_2 = new QLabel(page_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_6->addWidget(label_2, 0, 0, 1, 1);

        label_3 = new QLabel(page_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_6->addWidget(label_3, 1, 0, 1, 1);

        lineEdit_2 = new QLineEdit(page_4);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setReadOnly(true);

        gridLayout_6->addWidget(lineEdit_2, 1, 1, 1, 1);

        listView_2 = new QListView(page_4);
        listView_2->setObjectName(QString::fromUtf8("listView_2"));

        gridLayout_6->addWidget(listView_2, 5, 0, 1, 2);

        pushButton_3 = new QPushButton(page_4);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        gridLayout_6->addWidget(pushButton_3, 4, 0, 1, 2);

        stackedWidget_3->addWidget(page_4);
        page_5 = new QWidget();
        page_5->setObjectName(QString::fromUtf8("page_5"));
        gridLayout_10 = new QGridLayout(page_5);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        gridLayout_10->setContentsMargins(-1, -1, -1, 0);
        lineEdit_14 = new QLineEdit(page_5);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_14, 5, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_10->addItem(verticalSpacer_3, 10, 0, 1, 2);

        label_15 = new QLabel(page_5);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout_10->addWidget(label_15, 5, 0, 1, 1);

        lineEdit_13 = new QLineEdit(page_5);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_13, 4, 1, 1, 1);

        lineEdit_16 = new QLineEdit(page_5);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_16, 7, 1, 1, 1);

        label_16 = new QLabel(page_5);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout_10->addWidget(label_16, 6, 0, 1, 1);

        lineEdit_17 = new QLineEdit(page_5);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_17, 8, 1, 1, 1);

        label_11 = new QLabel(page_5);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_10->addWidget(label_11, 0, 0, 1, 1);

        lineEdit_15 = new QLineEdit(page_5);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_15, 6, 1, 1, 1);

        lineEdit_11 = new QLineEdit(page_5);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_11, 2, 1, 1, 1);

        label_12 = new QLabel(page_5);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_10->addWidget(label_12, 2, 0, 1, 1);

        lineEdit_10 = new QLineEdit(page_5);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_10, 0, 1, 1, 1);

        label_17 = new QLabel(page_5);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_10->addWidget(label_17, 7, 0, 1, 1);

        label_13 = new QLabel(page_5);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout_10->addWidget(label_13, 3, 0, 1, 1);

        label_18 = new QLabel(page_5);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_10->addWidget(label_18, 8, 0, 1, 1);

        label_14 = new QLabel(page_5);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_10->addWidget(label_14, 4, 0, 1, 1);

        lineEdit_12 = new QLineEdit(page_5);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setReadOnly(true);

        gridLayout_10->addWidget(lineEdit_12, 3, 1, 1, 1);

        pushButton_5 = new QPushButton(page_5);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        gridLayout_10->addWidget(pushButton_5, 9, 0, 1, 2);

        stackedWidget_3->addWidget(page_5);

        gridLayout_7->addWidget(stackedWidget_3, 0, 0, 1, 1);


        gridLayout_5->addLayout(gridLayout_7, 2, 1, 2, 1);

        gridLayout_5->setColumnStretch(0, 1);
        gridLayout_5->setColumnStretch(1, 1);
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        gridLayout_15 = new QGridLayout(page_2);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        label_19 = new QLabel(page_2);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        QSizePolicy sizePolicy5(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(label_19->sizePolicy().hasHeightForWidth());
        label_19->setSizePolicy(sizePolicy5);

        gridLayout_15->addWidget(label_19, 0, 0, 1, 1);

        spinBox_3 = new QSpinBox(page_2);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        spinBox_3->setValue(10);

        gridLayout_15->addWidget(spinBox_3, 1, 1, 1, 1);

        pushButton_10 = new QPushButton(page_2);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));

        gridLayout_15->addWidget(pushButton_10, 5, 0, 1, 2);

        spinBox_5 = new QSpinBox(page_2);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        spinBox_5->setValue(10);

        gridLayout_15->addWidget(spinBox_5, 3, 1, 1, 1);

        label_7 = new QLabel(page_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        sizePolicy5.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy5);

        gridLayout_15->addWidget(label_7, 1, 0, 1, 1);

        spinBox_4 = new QSpinBox(page_2);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setValue(10);

        gridLayout_15->addWidget(spinBox_4, 2, 1, 1, 1);

        label_9 = new QLabel(page_2);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        sizePolicy5.setHeightForWidth(label_9->sizePolicy().hasHeightForWidth());
        label_9->setSizePolicy(sizePolicy5);

        gridLayout_15->addWidget(label_9, 3, 0, 1, 1);

        label_8 = new QLabel(page_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        sizePolicy5.setHeightForWidth(label_8->sizePolicy().hasHeightForWidth());
        label_8->setSizePolicy(sizePolicy5);

        gridLayout_15->addWidget(label_8, 2, 0, 1, 1);

        label_10 = new QLabel(page_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        sizePolicy5.setHeightForWidth(label_10->sizePolicy().hasHeightForWidth());
        label_10->setSizePolicy(sizePolicy5);

        gridLayout_15->addWidget(label_10, 4, 0, 1, 1);

        spinBox_7 = new QSpinBox(page_2);
        spinBox_7->setObjectName(QString::fromUtf8("spinBox_7"));
        spinBox_7->setMaximum(100000);
        spinBox_7->setValue(10000);

        gridLayout_15->addWidget(spinBox_7, 0, 1, 1, 1);

        spinBox_6 = new QSpinBox(page_2);
        spinBox_6->setObjectName(QString::fromUtf8("spinBox_6"));
        spinBox_6->setValue(10);

        gridLayout_15->addWidget(spinBox_6, 4, 1, 1, 1);

        listWidget = new QListWidget(page_2);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        gridLayout_15->addWidget(listWidget, 6, 0, 1, 2);

        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QString::fromUtf8("page_3"));
        gridLayout_2 = new QGridLayout(page_3);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        stackedWidget_6 = new QStackedWidget(page_3);
        stackedWidget_6->setObjectName(QString::fromUtf8("stackedWidget_6"));
        page_15 = new QWidget();
        page_15->setObjectName(QString::fromUtf8("page_15"));
        gridLayout_18 = new QGridLayout(page_15);
        gridLayout_18->setSpacing(6);
        gridLayout_18->setContentsMargins(11, 11, 11, 11);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        spinBox = new QSpinBox(page_15);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        sizePolicy2.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
        spinBox->setSizePolicy(sizePolicy2);
        spinBox->setMinimumSize(QSize(150, 0));
        spinBox->setMaximum(9999);

        gridLayout_18->addWidget(spinBox, 1, 1, 1, 1);

        spinBox_2 = new QSpinBox(page_15);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setMinimumSize(QSize(150, 0));
        spinBox_2->setMaximum(9999);

        gridLayout_18->addWidget(spinBox_2, 3, 1, 1, 1);

        label = new QLabel(page_15);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_18->addWidget(label, 1, 0, 1, 1);

        label_6 = new QLabel(page_15);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_18->addWidget(label_6, 3, 0, 1, 1);

        pushButton = new QPushButton(page_15);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_18->addWidget(pushButton, 4, 0, 1, 2);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_18->addItem(verticalSpacer_2, 5, 0, 1, 2);

        stackedWidget_6->addWidget(page_15);
        page_17 = new QWidget();
        page_17->setObjectName(QString::fromUtf8("page_17"));
        gridLayout = new QGridLayout(page_17);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_21 = new QLabel(page_17);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        gridLayout->addWidget(label_21, 0, 0, 1, 1);

        lineEdit_8 = new QLineEdit(page_17);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));

        gridLayout->addWidget(lineEdit_8, 0, 1, 1, 1);

        lineEdit_9 = new QLineEdit(page_17);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));

        gridLayout->addWidget(lineEdit_9, 1, 1, 1, 1);

        lineEdit_18 = new QLineEdit(page_17);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));

        gridLayout->addWidget(lineEdit_18, 2, 1, 1, 1);

        label_28 = new QLabel(page_17);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        gridLayout->addWidget(label_28, 1, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 4, 0, 1, 2);

        label_29 = new QLabel(page_17);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        gridLayout->addWidget(label_29, 2, 0, 1, 1);

        pushButton_14 = new QPushButton(page_17);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));

        gridLayout->addWidget(pushButton_14, 3, 0, 1, 2);

        lineEdit_19 = new QLineEdit(page_17);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setReadOnly(true);

        gridLayout->addWidget(lineEdit_19, 5, 0, 1, 2);

        stackedWidget_6->addWidget(page_17);
        page_16 = new QWidget();
        page_16->setObjectName(QString::fromUtf8("page_16"));
        gridLayout_19 = new QGridLayout(page_16);
        gridLayout_19->setSpacing(6);
        gridLayout_19->setContentsMargins(11, 11, 11, 11);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        lineEdit_7 = new QLineEdit(page_16);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setReadOnly(true);

        gridLayout_19->addWidget(lineEdit_7, 9, 0, 1, 3);

        label_27 = new QLabel(page_16);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        gridLayout_19->addWidget(label_27, 6, 0, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_19->addItem(verticalSpacer_4, 8, 0, 1, 3);

        spinBox_12 = new QSpinBox(page_16);
        spinBox_12->setObjectName(QString::fromUtf8("spinBox_12"));

        gridLayout_19->addWidget(spinBox_12, 4, 2, 1, 1);

        pushButton_13 = new QPushButton(page_16);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));

        gridLayout_19->addWidget(pushButton_13, 7, 0, 1, 3);

        label_23 = new QLabel(page_16);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout_19->addWidget(label_23, 2, 0, 1, 1);

        label_24 = new QLabel(page_16);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout_19->addWidget(label_24, 3, 0, 1, 1);

        label_25 = new QLabel(page_16);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        gridLayout_19->addWidget(label_25, 4, 0, 1, 1);

        lineEdit_21 = new QLineEdit(page_16);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));

        gridLayout_19->addWidget(lineEdit_21, 6, 2, 1, 1);

        spinBox_13 = new QSpinBox(page_16);
        spinBox_13->setObjectName(QString::fromUtf8("spinBox_13"));

        gridLayout_19->addWidget(spinBox_13, 5, 2, 1, 1);

        label_26 = new QLabel(page_16);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout_19->addWidget(label_26, 5, 0, 1, 1);

        spinBox_11 = new QSpinBox(page_16);
        spinBox_11->setObjectName(QString::fromUtf8("spinBox_11"));

        gridLayout_19->addWidget(spinBox_11, 3, 2, 1, 1);

        lineEdit_6 = new QLineEdit(page_16);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));

        gridLayout_19->addWidget(lineEdit_6, 0, 2, 1, 1);

        label_22 = new QLabel(page_16);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout_19->addWidget(label_22, 1, 0, 1, 1);

        dateTimeEdit_5 = new QDateTimeEdit(page_16);
        dateTimeEdit_5->setObjectName(QString::fromUtf8("dateTimeEdit_5"));

        gridLayout_19->addWidget(dateTimeEdit_5, 2, 2, 1, 1);

        label_20 = new QLabel(page_16);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_19->addWidget(label_20, 0, 0, 1, 1);

        radioButton_2 = new QRadioButton(page_16);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));

        gridLayout_19->addWidget(radioButton_2, 1, 2, 1, 1);

        stackedWidget_6->addWidget(page_16);

        gridLayout_2->addWidget(stackedWidget_6, 0, 0, 1, 1);

        stackedWidget->addWidget(page_3);

        horizontalLayout->addWidget(stackedWidget);

        QT_SemesClass->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(QT_SemesClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        QT_SemesClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QT_SemesClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        QT_SemesClass->setStatusBar(statusBar);
        menuBar = new QMenuBar(QT_SemesClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1090, 22));
        menuPridat = new QMenu(menuBar);
        menuPridat->setObjectName(QString::fromUtf8("menuPridat"));
        menuManu_lne = new QMenu(menuPridat);
        menuManu_lne->setObjectName(QString::fromUtf8("menuManu_lne"));
        menuZobrazi = new QMenu(menuBar);
        menuZobrazi->setObjectName(QString::fromUtf8("menuZobrazi"));
        menuRegion_lne_celky = new QMenu(menuZobrazi);
        menuRegion_lne_celky->setObjectName(QString::fromUtf8("menuRegion_lne_celky"));
        menuTester = new QMenu(menuBar);
        menuTester->setObjectName(QString::fromUtf8("menuTester"));
        QT_SemesClass->setMenuBar(menuBar);

        menuBar->addAction(menuPridat->menuAction());
        menuBar->addAction(menuZobrazi->menuAction());
        menuBar->addAction(menuTester->menuAction());
        menuPridat->addAction(actionGenerator);
        menuPridat->addAction(menuManu_lne->menuAction());
        menuManu_lne->addAction(actionOsoba_2);
        menuManu_lne->addAction(actionTest_3);
        menuZobrazi->addAction(actionOsoba);
        menuZobrazi->addAction(actionTest);
        menuZobrazi->addAction(menuRegion_lne_celky->menuAction());
        menuZobrazi->addAction(actionTestovacie_Stanice);
        menuRegion_lne_celky->addAction(actionSlovensko_3);
        menuRegion_lne_celky->addAction(actionKraje);
        menuRegion_lne_celky->addAction(actionOkresy);
        menuTester->addAction(actionTest_2);

        retranslateUi(QT_SemesClass);

        stackedWidget->setCurrentIndex(2);
        stackedWidget_4->setCurrentIndex(1);
        stackedWidget_5->setCurrentIndex(2);
        stackedWidget_2->setCurrentIndex(3);
        stackedWidget_3->setCurrentIndex(1);
        stackedWidget_6->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(QT_SemesClass);
    } // setupUi

    void retranslateUi(QMainWindow *QT_SemesClass)
    {
        QT_SemesClass->setWindowTitle(QCoreApplication::translate("QT_SemesClass", "QT_Semes", nullptr));
        actionGenerator->setText(QCoreApplication::translate("QT_SemesClass", "Gener\303\241tor", nullptr));
        actionManu_lne->setText(QCoreApplication::translate("QT_SemesClass", "Manu\303\241lne", nullptr));
        actionGenerova->setText(QCoreApplication::translate("QT_SemesClass", "Generova\305\245", nullptr));
        actionSlovensko->setText(QCoreApplication::translate("QT_SemesClass", "Slovensko", nullptr));
        actionKraj->setText(QCoreApplication::translate("QT_SemesClass", "Kraj", nullptr));
        actionOkres->setText(QCoreApplication::translate("QT_SemesClass", "Okres", nullptr));
        actionOsoba->setText(QCoreApplication::translate("QT_SemesClass", "Osoba", nullptr));
        actionTest->setText(QCoreApplication::translate("QT_SemesClass", "Test", nullptr));
        actionTestovacie_Stanice->setText(QCoreApplication::translate("QT_SemesClass", "Testovacie Stanice", nullptr));
        actionSlovensko_2->setText(QCoreApplication::translate("QT_SemesClass", "Slovensko", nullptr));
        actionSlovensko_3->setText(QCoreApplication::translate("QT_SemesClass", "Slovensko", nullptr));
        actionKraje->setText(QCoreApplication::translate("QT_SemesClass", "Kraje", nullptr));
        actionOkresy->setText(QCoreApplication::translate("QT_SemesClass", "Okresy", nullptr));
        actionTest_2->setText(QCoreApplication::translate("QT_SemesClass", "Test \305\241trukt\303\272ry", nullptr));
        actionOsoba_2->setText(QCoreApplication::translate("QT_SemesClass", "Osoba", nullptr));
        actionTest_3->setText(QCoreApplication::translate("QT_SemesClass", "Test", nullptr));
        dateTimeEdit_2->setDisplayFormat(QCoreApplication::translate("QT_SemesClass", "d.M.yyyy H:m:s", nullptr));
        radioButton->setText(QCoreApplication::translate("QT_SemesClass", "Len pozit\303\255vni", nullptr));
        dateTimeEdit->setDisplayFormat(QCoreApplication::translate("QT_SemesClass", "d.M.yyyy H:m:s", nullptr));
        pushButton_2->setText(QCoreApplication::translate("QT_SemesClass", "Filtrova\305\245", nullptr));
        pushButton_6->setText(QCoreApplication::translate("QT_SemesClass", "Reset", nullptr));
        pushButton_7->setText(QCoreApplication::translate("QT_SemesClass", "Filtrova\305\245", nullptr));
        pushButton_8->setText(QCoreApplication::translate("QT_SemesClass", "Reset", nullptr));
        pushButton_4->setText(QCoreApplication::translate("QT_SemesClass", "Filtrova\305\245", nullptr));
        pushButton_9->setText(QCoreApplication::translate("QT_SemesClass", "Reset", nullptr));
        pushButton_11->setText(QCoreApplication::translate("QT_SemesClass", "Filtrova\305\245", nullptr));
        pushButton_12->setText(QCoreApplication::translate("QT_SemesClass", "Reset", nullptr));
        label_5->setText(QCoreApplication::translate("QT_SemesClass", "D\303\241tum narodenia", nullptr));
        label_4->setText(QCoreApplication::translate("QT_SemesClass", "Rodn\303\251 \304\215\303\255slo", nullptr));
        label_2->setText(QCoreApplication::translate("QT_SemesClass", "Meno", nullptr));
        label_3->setText(QCoreApplication::translate("QT_SemesClass", "Priezvisko", nullptr));
        pushButton_3->setText(QCoreApplication::translate("QT_SemesClass", "Vymaza\305\245 osobu", nullptr));
        label_15->setText(QCoreApplication::translate("QT_SemesClass", "Kraj", nullptr));
        label_16->setText(QCoreApplication::translate("QT_SemesClass", "Okres", nullptr));
        label_11->setText(QCoreApplication::translate("QT_SemesClass", "Rodn\303\251 \304\215\303\255slo", nullptr));
        label_12->setText(QCoreApplication::translate("QT_SemesClass", "UUID", nullptr));
        label_17->setText(QCoreApplication::translate("QT_SemesClass", "Odbern\303\251 miesto", nullptr));
        label_13->setText(QCoreApplication::translate("QT_SemesClass", "V\303\275sledok", nullptr));
        label_18->setText(QCoreApplication::translate("QT_SemesClass", "Koment\303\241r", nullptr));
        label_14->setText(QCoreApplication::translate("QT_SemesClass", "D\303\241tum testovania", nullptr));
        pushButton_5->setText(QCoreApplication::translate("QT_SemesClass", "Vymaza\305\245 test", nullptr));
        label_19->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et oper\303\241cii", nullptr));
        pushButton_10->setText(QCoreApplication::translate("QT_SemesClass", "Testuj", nullptr));
        label_7->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et vlo\305\276", nullptr));
        label_9->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et pristup", nullptr));
        label_8->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et vyber", nullptr));
        label_10->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et interaval", nullptr));
        label->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et generovan\303\275ch mien", nullptr));
        label_6->setText(QCoreApplication::translate("QT_SemesClass", "Po\304\215et testov pre osobu", nullptr));
        pushButton->setText(QCoreApplication::translate("QT_SemesClass", "Generova\305\245", nullptr));
        label_21->setText(QCoreApplication::translate("QT_SemesClass", "Rodn\303\251 \304\215islo", nullptr));
        label_28->setText(QCoreApplication::translate("QT_SemesClass", "Meno", nullptr));
        label_29->setText(QCoreApplication::translate("QT_SemesClass", "Priezvisko", nullptr));
        pushButton_14->setText(QCoreApplication::translate("QT_SemesClass", "PushButton", nullptr));
        label_27->setText(QCoreApplication::translate("QT_SemesClass", "Koment\303\241r", nullptr));
        pushButton_13->setText(QCoreApplication::translate("QT_SemesClass", "Prida\305\245 test", nullptr));
        label_23->setText(QCoreApplication::translate("QT_SemesClass", "D\303\241tum", nullptr));
        label_24->setText(QCoreApplication::translate("QT_SemesClass", "Kraj", nullptr));
        label_25->setText(QCoreApplication::translate("QT_SemesClass", "Okres", nullptr));
        label_26->setText(QCoreApplication::translate("QT_SemesClass", "Odbern\303\251 miesto", nullptr));
        label_22->setText(QCoreApplication::translate("QT_SemesClass", "V\303\275sledok", nullptr));
        label_20->setText(QCoreApplication::translate("QT_SemesClass", "Rodn\303\251 \304\215\303\255slo", nullptr));
        radioButton_2->setText(QCoreApplication::translate("QT_SemesClass", "Pozit\303\255vny", nullptr));
        menuPridat->setTitle(QCoreApplication::translate("QT_SemesClass", "Prida\305\245", nullptr));
        menuManu_lne->setTitle(QCoreApplication::translate("QT_SemesClass", "Manu\303\241lne", nullptr));
        menuZobrazi->setTitle(QCoreApplication::translate("QT_SemesClass", "Zobrazi\305\245", nullptr));
        menuRegion_lne_celky->setTitle(QCoreApplication::translate("QT_SemesClass", "Region\303\241lne celky", nullptr));
        menuTester->setTitle(QCoreApplication::translate("QT_SemesClass", "Tester", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QT_SemesClass: public Ui_QT_SemesClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_SEMES_H
