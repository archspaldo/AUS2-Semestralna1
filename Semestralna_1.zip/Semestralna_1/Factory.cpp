#include "Factory.h"
namespace AUS2
{
	Person *AUS2::PersonFactory::create(const std::string &id, const std::string &name, const std::string &surname)
	{
		std::string year = id.substr(0, 2), month = id.substr(2, 2);
		year = year > "90" ? "19" + year : "20" + year;
		if (month > "50") {
			month.data()[0] -= 5;
		}
		struct tm *date = new tm;
		std::istringstream ss{ id.substr(4, 2) + "." + month + "." + year };
		ss >> std::get_time(date, "%d.%m.%Y");
		return new Person(id, name, surname, date);
	}

	Person *PersonFactory::create()
	{
		return nullptr;
	}

	Test *TestFactory::create(Person *person, const int &district, const int &county, const int &station, const bool &result, const std::string &date_of_test, const std::string &comment)
	{
		UUID uuid;
		std::string s_uuid;
		UuidCreate(&uuid);
		UuidToStringA(&uuid, (RPC_CSTR *)&s_uuid);
		struct tm *date = new tm;
		std::istringstream ss{ date_of_test };
		ss >> std::get_time(date, "%d.%m.%Y %H:%M:%S ");
		return new Test(s_uuid, person, district, county, station, result, date, comment);
	}

	Test *TestFactory::create(Person *person)
	{
		return nullptr;
	}
}
